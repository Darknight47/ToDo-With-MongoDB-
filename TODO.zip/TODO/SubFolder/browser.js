document.addEventListener("click", function(e) {
  if (e.target.classList.contains("edit-me")) {
    let userInp = prompt(
      "You can re-write your to-do item",
      e.target.parentElement.parentElement.querySelector(".item-text").innerHTML
    );
    //console.log(userInp);
    if (userInp) {
      axios
        .post("/update-item", {
          text: userInp,
          id: e.target.getAttribute("data-id")
        })
        .then(function() {
          e.target.parentElement.parentElement.querySelector(
            ".item-text"
          ).innerHTML = userInp;
        })
        .catch(function() {
          console.log("Try Again later");
        });
    }
  }
});
